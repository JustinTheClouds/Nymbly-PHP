<?php
return array(
    'SEF::setRoute must be called with at least a single param passed in.' => 'SEF::setRoute must be called with at least a single param passed in.'
);
?>